/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;


public class Persona {
    String email, telefonoCelular, dni;
    private String nombreCompleto;

    public Persona(String email, String telefonoCelular, String dni, String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
        this.email = email;
        this.telefonoCelular = telefonoCelular;
        this.dni = dni;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefonoCelular() {
        return telefonoCelular;
    }

    public void setTelefonoCelular(String telefonoCelular) {
        this.telefonoCelular = telefonoCelular;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

   
    void mostrarContacto(){
        System.out.println(this.getNombreCompleto() + this.getDni() + this.getEmail() + this.getTelefonoCelular());
       
    }
   
}
