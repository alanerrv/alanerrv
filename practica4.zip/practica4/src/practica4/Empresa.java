/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica4;


    public class Empresa extends Contacto{
   
    String webSite, cuit, telefonoFijo;

    public Empresa(String telefonoFijo, String webSite, String cuit, String nombreCompleto) {
        super(nombreCompleto);
        this.telefonoFijo = telefonoFijo;
        this.webSite = webSite;
        this.cuit = cuit;
    }

    public String getTelefonoFijo() {
        return telefonoFijo;
    }

    public void setTelefonoFijo(String telefonoFijo) {
        this.telefonoFijo = telefonoFijo;
    }

    public String getWebSite() {
        return webSite;
    }

    public void setWebSite(String webSite) {
        this.webSite = webSite;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

   
    void motrarContacto(){
        System.out.println("Nombre: " + this.getNombreCompleto() + "Telefono fijo: " + this.getTelefonoFijo() +
                "Pagina Web: " + this.getWebSite() + "CUIT: " + this.getCuit());
    }
   
    void mostrarContacto(){
       
        System.out.println(this.getNombreCompleto() + this.getWebSite() + this.getCuit() + this.getTelefonoFijo());   
    }
   
}

