/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3.pkg1;

/**
 *
 * @author Gloria
 */
public interface IFunciones {
    
    public String cambioCanal();
    public String volumen();
    
}
