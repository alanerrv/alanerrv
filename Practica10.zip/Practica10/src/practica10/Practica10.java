package practica10;

public class Practica10 {
  
     public static void main(String[]args){
        Lectores leer = new Lectores();
        Vehiculo carro = new Vehiculo();
        String dato;
        System.out.println("Ingrese matricula del vehiculo: ");
        dato = leer.leerCadena();
        carro.setMatricula(dato);
        System.out.println("Ingrese marca de carro(Ford,Toyota,Suzuki,Renault,Seat).");
        dato = leer.leerCadena();
        carro.setMarca(dato);
        System.out.printf("El Automovil Marca " + carro.getMarca() + " Matricula " + carro.getMatricula() + ".");
    }
    }


