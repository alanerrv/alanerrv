
package practica2;
import java.util.Scanner;

public class main {


    public static void main(String[] args) {
        

        
   
    }
    
}
