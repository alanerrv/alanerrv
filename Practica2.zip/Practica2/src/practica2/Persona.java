
package practica2;

public class Persona {
    private String nombre;
    private int edad;
    private float altura;
    private char genero;
    private float peso;
    
    public Persona(String nombre, int edad, char genero){
        
    }


    public float calcularIMC(){
        float IMC;

        IMC = (float) (peso / (Math.pow(altura, 2)));
        if (IMC < 20) {
            System.out.println("Usted está por debajo de su peso ideal");
        } else if (IMC < 20 && IMC > 25) {

            System.out.println("Usted está en su peso ideal");
        } else if (IMC > 25) {
            System.out.println("Usted tiene sobrepeso");
        }
        return IMC;
    }
       
    public int esMayorDeEdad(){
        boolean mayor;
        if(edad>17){
            System.out.println("");
            mayor=true;
    }else {
            System.out.println("");
            mayor=false;
    }
        return 0;
    }
    
    public char comprobarGenero(char genero){
        if(genero=='H'){
            System.out.println("HOMBRE");
            
    } else if(genero=='M'){
            System.out.println("MUJER");
    }else{
            genero='H';
            System.out.println("HOMBRE");
    }
        return 0;
    }
    
    
            
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    
}
